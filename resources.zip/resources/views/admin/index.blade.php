@extends("admin.app")

@section("page_title")
<li class="breadcrumb-item">
    <a href="#" class="text-muted">Dashboard</a>
</li>

@endsection

@section("page_content")

@endsection