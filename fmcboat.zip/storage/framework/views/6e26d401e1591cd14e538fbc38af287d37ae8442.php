

<?php $__env->startSection("page_title"); ?>
<li class="breadcrumb-item">
    <a href="/admins" class="text-muted">Dashboard</a>
</li>
<li class="breadcrumb-item">
    <a href="#" class="text-muted">Products</a>
</li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection("page_content"); ?>
<h1>PRODUCTS</h1>
<a href="/admin/products/table">Click to table</a>
<?php $__env->stopSection(); ?>

<?php $__env->startSection("page_nav"); ?>
<a href="/admin/products/table" class="btn btn-light-primary btn-sm font-weight-bold mr-2">
    Table
</a>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("admin.app", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\fmcboat\resources\views/admin/products.blade.php ENDPATH**/ ?>