

<?php $__env->startSection("page_title"); ?>
<li class="breadcrumb-item">
    <a href="#" class="text-muted">Dashboard</a>
</li>

<?php $__env->stopSection(); ?>

<?php $__env->startSection("page_content"); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make("admin.app", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\fmcboat\resources\views/admin/index.blade.php ENDPATH**/ ?>